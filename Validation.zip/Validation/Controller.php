<?php
include 'model.php';
class Controller extends Model
{
	
	public function __construct()
	{
		parent::__construct();
		switch ($_SERVER['PATH_INFO']) {
			case '/logout':
			session_start();
			session_destroy();
			header('location:login');
				break;
			case '/login':
				include 'login.php';
				if(isset($_POST['Login']))
				{
					$email =$_POST['email'];
					$password = $_POST['password'];

					 $data = array("email" =>$email,"password" =>$password);
					 $ins =$this->insert("reg",$data);
					 if($ins)
					 {
					 	echo "Successfully Record";
					 }
					 else
					 {
					 	echo "Error";
					 }
				}
				break;
				case '/Registration':
				if(isset($_POST['Registration']))
				{
					$reg_fname = $_POST['fname'];
					$reg_email = $_POST['email'];
					$reg_password = $_POST['password'];
					$data = array("reg_fname"=>$reg_fname,
								  "reg_email"=>$reg_email,
								  "reg_password"=>$reg_password
								);
					  $insert =$this->insert("User",$data);
					  if ($insert) {
					  	
					  		redirect('Controller/Registration');
					  }
					  else
					  {
					  	echo "Error";
					  }


				}
					include 'reg.php';
					break;
					case '/Showdata':
						include 'showdata.php';
						$this->Select_all("reg");
						break;

			
			default:
				# code...
				break;
		}
	}
}


?>