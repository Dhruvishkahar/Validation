<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>



<form method="POST">
<label>Email</label>
<input type="text" name="email" id="email">
<span id="eemail"></span><br>
<label>Password</label>
<input type="password" name="password" id="password">
<span id="epassword"></span><br>
	<input type="button" name="Login"  id="login" value="Login">
</form>

<script type="text/javascript">
	


$(document).ready(function(){


	$('#login').click(function(){

			var email = $('#email').val();
			//alert(email);
			if(email == '')
			{
				//alert('please fill email');
				$eemail = $('#eemail').html('please fill email');

				$eemail.css("color","red");
		
		return false;

			}

	});



});



</script>



