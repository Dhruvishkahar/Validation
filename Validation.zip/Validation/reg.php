<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
</head>
<body>
<form>
	<table>
		<tr>
			<th>FirstName</th>
			<td><input type="text" name="fname"></td>
		</tr>
		<tr>
			<th>Email</th>
			<td><input type="text" name="email"></td>
		</tr>
		<tr>
			<th>Password</th>
			<td><input type="password" name="password"></td>
		</tr>
		<tr>
			<td><input type="submit" name="Registration" value="Registration"></td>
		</tr>
	</table>
</form>
</body>
</html>