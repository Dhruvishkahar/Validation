<?php
	class Model 
	{
		public $db;
		public function __construct()
		{
			$this->db = new mysqli("localhost","root","","25_mvc");
			if($this->db)
			{
				echo "Database Connected";
			}
			else
			{
				echo "Error";
			}

		}
		public function insert($table,$data)
		{
			$keys = implode('`,`',array_keys($data));

			$values = implode("','", array_values($data));

			$sql = "INSERT INTO $table (`$keys`) VALUES ('$values')";

			return $ex = $this->db->query($sql);


		}
	}

?>