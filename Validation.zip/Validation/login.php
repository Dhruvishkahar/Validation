

<!DOCTYPE html>
<html>
<head>
	<title>Validtion</title>
</head>
<body>
<form method="POST" onsubmit="return validation()">
<label>Email</label>
<input type="text" name="email" id="email">
<span id="xx"></span><br>
<label>Password</label>
<input type="password" name="password" id="password">
<span id="epassword"></span><br>

	<input type="submit" name="Login" value="Login">
</form>
<script type="text/javascript">

function validation()
{
	var email = document.getElementById('email').value;
	var password =document.getElementById('password').value;
	//alert(password);

	if(email == '')
	{
		//alert('oke');
		var eemail = document.getElementById('xx');
		eemail.innerHTML="please fill Email";
		eemail.style.color = "red";
		return false;

	}


	
}

</script>

</body>
</html>